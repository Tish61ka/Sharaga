<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AuthMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        if(DB::table('users')->where('token', $request->input('token'))->get()->first()){
            return $next($request);
        }
        else{
            return response(json_encode([
                'message' => "Ты гость",
                'code' => 403,
            ],
            JSON_UNESCAPED_UNICODE), 403);
        }
    }
}
